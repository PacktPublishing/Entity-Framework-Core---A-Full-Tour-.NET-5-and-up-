﻿using System;

namespace EntityFrameworkNet5.ConsoleApp.ScaffoldDb.Sample
{
    public class Class1
    {
    }
}
